import React from 'react';
import { Calendar, MapPin, Tag, ArrowRight } from 'lucide-react';

interface Item {
  id: string;
  name: string;
  category: string;
  description: string;
  date: string;
  location: string;
  status: 'Lost' | 'Found';
}

interface ItemCardProps {
  item: Item;
}

export const ItemCard = ({ item }: ItemCardProps) => {
  const isLost = item.status === 'Lost';
  
  return (
    <div className="bg-white rounded-xl border border-gray-200 overflow-hidden hover:shadow-lg transition-shadow group">
      <div className={`h-1 w-full ${isLost ? 'bg-red-500' : 'bg-emerald-500'}`} />
      
      <div className="p-5">
        <div className="flex justify-between items-start mb-3">
          <span className={`px-2 py-1 rounded-md text-xs font-semibold uppercase tracking-wider ${
            isLost ? 'bg-red-50 text-red-700' : 'bg-emerald-50 text-emerald-700'
          }`}>
            {item.status}
          </span>
          <span className="text-xs text-gray-500 font-medium flex items-center gap-1">
            <Tag className="w-3 h-3" />
            {item.category}
          </span>
        </div>

        <h3 className="text-lg font-bold text-gray-900 mb-2 group-hover:text-blue-600 transition-colors line-clamp-1">
          {item.name}
        </h3>
        
        <p className="text-gray-600 text-sm mb-4 line-clamp-2 min-h-[2.5rem]">
          {item.description}
        </p>

        <div className="space-y-2 border-t border-gray-50 pt-4">
          <div className="flex items-center gap-2 text-xs text-gray-500">
            <Calendar className="w-3.5 h-3.5" />
            <span>{item.date}</span>
          </div>
          <div className="flex items-center gap-2 text-xs text-gray-500">
            <MapPin className="w-3.5 h-3.5" />
            <span className="truncate">{item.location}</span>
          </div>
        </div>

        <button className="mt-5 w-full flex items-center justify-center gap-2 py-2 px-4 rounded-lg bg-gray-50 text-gray-700 text-sm font-semibold hover:bg-blue-600 hover:text-white transition-all">
          View Details
          <ArrowRight className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};
