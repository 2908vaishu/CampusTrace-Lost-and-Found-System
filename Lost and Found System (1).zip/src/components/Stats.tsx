import React from 'react';
import { Search, Map, CheckCircle2, AlertCircle } from 'lucide-react';

interface StatsProps {
  totalLost: number;
  totalFound: number;
  resolved: number;
}

export const Stats = ({ totalLost, totalFound, resolved }: StatsProps) => {
  const items = [
    { label: 'Lost Items', value: totalLost, icon: AlertCircle, color: 'text-red-600', bg: 'bg-red-50' },
    { label: 'Found Items', value: totalFound, icon: Search, color: 'text-emerald-600', bg: 'bg-emerald-50' },
    { label: 'Recently Resolved', value: resolved, icon: CheckCircle2, color: 'text-blue-600', bg: 'bg-blue-50' },
  ];

  return (
    <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-8">
      {items.map((item, idx) => (
        <div key={idx} className="bg-white p-6 rounded-2xl border border-gray-100 shadow-sm flex items-center gap-4">
          <div className={`${item.bg} p-3 rounded-xl`}>
            <item.icon className={`w-6 h-6 ${item.color}`} />
          </div>
          <div>
            <p className="text-sm font-medium text-gray-500">{item.label}</p>
            <p className="text-2xl font-bold text-gray-900">{item.value}</p>
          </div>
        </div>
      ))}
    </div>
  );
};
