import React from 'react';
import { Search, PlusCircle, User, Bell } from 'lucide-react';

export const Header = () => {
  return (
    <header className="bg-white border-b border-gray-200 sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center gap-2">
            <div className="bg-blue-600 p-2 rounded-lg">
              <Search className="w-5 h-5 text-white" />
            </div>
            <span className="text-xl font-bold bg-clip-text text-transparent bg-linear-to-r from-blue-600 to-indigo-600">
              CampusTrace
            </span>
          </div>
          
          <div className="hidden md:flex items-center gap-8">
            <nav className="flex gap-6">
              <a href="#" className="text-sm font-medium text-gray-700 hover:text-blue-600 transition-colors">Dashboard</a>
              <a href="#" className="text-sm font-medium text-gray-700 hover:text-blue-600 transition-colors">Report Item</a>
              <a href="#" className="text-sm font-medium text-gray-700 hover:text-blue-600 transition-colors">My Items</a>
              <a href="#" className="text-sm font-medium text-gray-700 hover:text-blue-600 transition-colors">Safety Guide</a>
            </nav>
          </div>

          <div className="flex items-center gap-4">
            <button className="p-2 text-gray-500 hover:bg-gray-100 rounded-full transition-colors relative">
              <Bell className="w-5 h-5" />
              <span className="absolute top-2 right-2 w-2 h-2 bg-red-500 rounded-full border-2 border-white"></span>
            </button>
            <div className="h-8 w-8 rounded-full bg-blue-100 flex items-center justify-center border border-blue-200 cursor-pointer">
              <User className="w-4 h-4 text-blue-600" />
            </div>
          </div>
        </div>
      </div>
    </header>
  );
};
