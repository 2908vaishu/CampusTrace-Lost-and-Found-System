import React, { useState, useEffect } from 'react';
import { Header } from './components/Header';
import { ItemCard } from './components/ItemCard';
import { ItemForm } from './components/ItemForm';
import { Stats } from './components/Stats';
import { ImageWithFallback } from './components/figma/ImageWithFallback';
import { Search, Filter, Plus, ChevronDown, PackageSearch } from 'lucide-react';

interface Item {
  id: string;
  name: string;
  category: string;
  description: string;
  date: string;
  location: string;
  status: 'Lost' | 'Found';
}

const INITIAL_ITEMS: Item[] = [
  {
    id: '1',
    name: 'MacBook Air M2',
    category: 'Electronics',
    description: 'Silver MacBook Air with a stickers of stickers on the lid. Left in the cafeteria.',
    date: '2026-01-28',
    location: 'Main Cafeteria',
    status: 'Lost'
  },
  {
    id: '2',
    name: 'Leather Wallet',
    category: 'Wallet',
    description: 'Brown leather wallet containing a student ID card and some cash.',
    date: '2026-01-30',
    location: 'Student Union Building',
    status: 'Found'
  },
  {
    id: '3',
    name: 'Car Keys',
    category: 'Keys',
    description: 'Toyota car keys with a red keychain and a house key.',
    date: '2026-01-31',
    location: 'Parking Lot C',
    status: 'Found'
  },
  {
    id: '4',
    name: 'Blue North Face Backpack',
    category: 'Bag',
    description: 'Contained several textbooks and a scientific calculator.',
    date: '2026-01-25',
    location: 'Library Floor 3',
    status: 'Lost'
  }
];

export default function App() {
  const [items, setItems] = useState<Item[]>([]);
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [filterStatus, setFilterStatus] = useState<'All' | 'Lost' | 'Found'>('All');
  const [filterCategory, setFilterCategory] = useState('All');

  useEffect(() => {
    const saved = localStorage.getItem('lostFoundItems');
    if (saved) {
      setItems(JSON.parse(saved));
    } else {
      setItems(INITIAL_ITEMS);
    }
  }, []);

  const handleAddItem = (newItem: Item) => {
    const updated = [newItem, ...items];
    setItems(updated);
    localStorage.setItem('lostFoundItems', JSON.stringify(updated));
  };

  const filteredItems = items.filter(item => {
    const matchesSearch = item.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          item.description.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesStatus = filterStatus === 'All' || item.status === filterStatus;
    const matchesCategory = filterCategory === 'All' || item.category === filterCategory;
    return matchesSearch && matchesStatus && matchesCategory;
  });

  const stats = {
    totalLost: items.filter(i => i.status === 'Lost').length,
    totalFound: items.filter(i => i.status === 'Found').length,
    resolved: 12 // Mock resolved count
  };

  const categories = ['All', ...Array.from(new Set(items.map(i => i.category)))];

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col font-sans">
      <Header />

      <main className="flex-1 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 w-full">
        {/* Hero Section */}
        <div className="relative rounded-3xl overflow-hidden mb-12 bg-blue-600 h-[300px] sm:h-[400px]">
          <ImageWithFallback
            src="https://images.unsplash.com/photo-1632834380561-d1e05839a33a?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx1bml2ZXJzaXR5JTIwY2FtcHVzJTIwc3R1ZGVudHN8ZW58MXx8fHwxNzY5NzMxNTY3fDA&ixlib=rb-4.1.0&q=80&w=1080"
            alt="University Campus"
            className="absolute inset-0 w-full h-full object-cover mix-blend-overlay opacity-60"
          />
          <div className="absolute inset-0 flex flex-col justify-center px-8 sm:px-12 bg-linear-to-r from-blue-900/60 to-transparent">
            <h1 className="text-4xl sm:text-6xl font-extrabold text-white mb-4 leading-tight">
              Lost something? <br />
              <span className="text-blue-300">We'll help you find it.</span>
            </h1>
            <p className="text-blue-50 text-lg sm:text-xl max-w-2xl mb-8">
              The official university portal for reporting and finding lost items on campus. Connect with fellow students and faculty to recover your belongings.
            </p>
            <div className="flex flex-wrap gap-4">
              <button 
                onClick={() => setIsFormOpen(true)}
                className="bg-white text-blue-600 px-8 py-4 rounded-xl font-bold flex items-center gap-2 hover:bg-blue-50 transition-all shadow-xl hover:shadow-2xl transform hover:-translate-y-1"
              >
                <Plus className="w-5 h-5" />
                Report an Item
              </button>
              <button className="bg-blue-500/30 backdrop-blur-md text-white border border-white/30 px-8 py-4 rounded-xl font-bold flex items-center gap-2 hover:bg-blue-500/40 transition-all">
                Learn How it Works
              </button>
            </div>
          </div>
        </div>

        <Stats {...stats} />

        {/* Search and Filters */}
        <div className="bg-white p-4 rounded-2xl border border-gray-100 shadow-sm mb-8 space-y-4 md:space-y-0 md:flex md:items-center md:gap-4">
          <div className="relative flex-1">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400 w-5 h-5" />
            <input
              type="text"
              placeholder="Search by item name or description..."
              className="w-full pl-12 pr-4 py-3 bg-gray-50 border-transparent rounded-xl focus:bg-white focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all outline-hidden text-gray-700"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
          
          <div className="flex gap-4">
            <div className="relative">
              <select
                className="appearance-none bg-gray-50 pl-4 pr-10 py-3 rounded-xl border-transparent focus:bg-white focus:ring-2 focus:ring-blue-500 transition-all outline-hidden text-gray-700 font-medium cursor-pointer"
                value={filterStatus}
                onChange={(e) => setFilterStatus(e.target.value as any)}
              >
                <option value="All">All Status</option>
                <option value="Lost">Lost</option>
                <option value="Found">Found</option>
              </select>
              <ChevronDown className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 w-4 h-4 pointer-events-none" />
            </div>

            <div className="relative">
              <select
                className="appearance-none bg-gray-50 pl-4 pr-10 py-3 rounded-xl border-transparent focus:bg-white focus:ring-2 focus:ring-blue-500 transition-all outline-hidden text-gray-700 font-medium cursor-pointer"
                value={filterCategory}
                onChange={(e) => setFilterCategory(e.target.value)}
              >
                {categories.map(cat => (
                  <option key={cat} value={cat}>{cat === 'All' ? 'All Categories' : cat}</option>
                ))}
              </select>
              <ChevronDown className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 w-4 h-4 pointer-events-none" />
            </div>
          </div>
        </div>

        {/* Items Grid */}
        <div className="space-y-6">
          <div className="flex justify-between items-center">
            <h2 className="text-2xl font-bold text-gray-900 flex items-center gap-2">
              Recent Reports
              <span className="bg-blue-100 text-blue-600 px-2.5 py-0.5 rounded-full text-sm font-medium">
                {filteredItems.length}
              </span>
            </h2>
          </div>

          {filteredItems.length > 0 ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {filteredItems.map(item => (
                <ItemCard key={item.id} item={item} />
              ))}
            </div>
          ) : (
            <div className="bg-white rounded-3xl border-2 border-dashed border-gray-200 py-20 px-4 text-center">
              <div className="bg-gray-50 w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-6">
                <PackageSearch className="w-10 h-10 text-gray-300" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-2">No items found</h3>
              <p className="text-gray-500 max-w-sm mx-auto">
                Try adjusting your search or filters to find what you're looking for.
              </p>
            </div>
          )}
        </div>
      </main>

      <footer className="bg-white border-t border-gray-100 py-12 mt-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="flex items-center justify-center gap-2 mb-4">
            <div className="bg-blue-600 p-1.5 rounded-lg">
              <Search className="w-4 h-4 text-white" />
            </div>
            <span className="text-lg font-bold text-gray-900">CampusTrace</span>
          </div>
          <p className="text-gray-500 text-sm max-w-md mx-auto">
            Helping our community stay connected and recover lost belongings since 2026.
          </p>
          <div className="mt-8 pt-8 border-t border-gray-50 flex flex-col sm:flex-row justify-between items-center gap-4 text-sm text-gray-400">
            <p>© 2026 University Lost & Found. All rights reserved.</p>
            <div className="flex gap-6">
              <a href="#" className="hover:text-blue-600">Privacy Policy</a>
              <a href="#" className="hover:text-blue-600">Terms of Service</a>
              <a href="#" className="hover:text-blue-600">Contact Security</a>
            </div>
          </div>
        </div>
      </footer>

      {isFormOpen && (
        <ItemForm 
          onClose={() => setIsFormOpen(false)} 
          onSubmit={handleAddItem}
        />
      )}
    </div>
  );
}
