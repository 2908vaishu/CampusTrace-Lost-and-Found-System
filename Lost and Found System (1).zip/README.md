
  # Lost and Found System

  This is a code bundle for Lost and Found System. The original project is available at https://www.figma.com/design/cka9GvoFWpzZnSSG6Zqhxt/Lost-and-Found-System.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  